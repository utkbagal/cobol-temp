from app.agents.base import BaseAgent
from app.rag.retriever import retrieve_for_pol
from app.utils.llm_client import chat_with_backoff
from app.agents.prompt_templates import COMPLIANCE_PROMPT
from app.utils.observability import Timer, track_event


class ComplianceAgent(BaseAgent):
    name = "ComplianceAgent"

    async def run(self, state):
        cid = state.correlation_id

        ## fetch policy docs first -> 
        hits = await retrieve_for_pol(cid=cid, k=8)
        list_of_documents = hits.get('documents', []) 
        documents_flat_list = list_of_documents[0] if list_of_documents else []

        context1 = "POLICY DOCUMENT: \n\n".join([doc for doc in documents_flat_list])

        ## use data from intake_agent for compliance check -> 
        try:
            intake_agent_output = next(
                str(step.get("output", {}).get("agent_output"))
                for step in state.steps
                if step.get("agent") == 'intakeAgent'
            )
        # Use intake_agent_output as needed
            context2 = intake_agent_output
        except StopIteration:
        # Handle the case where no agent named 'intakeAgent' was found
            context2 = "IntakeAgent Output: No intakeAgent output found in steps."

        context = context1 + context2
        prompt = COMPLIANCE_PROMPT.format(context=context)

        resp = chat_with_backoff(
            [{"role": "user", "content": prompt}],
            cid,
            response_format={"type": "json_object"}
        )
        compliance_out = resp.choices[0].message.content.strip()
        track_event("Compliance assessment",cid,{"compliance_out":compliance_out})
        output = {
            "agent_output": compliance_out,
            "evidence": hits
        }

        state.steps.append({"agent": self.name, "output": output})
        state.context["compliance"] = compliance_out
 
        return state