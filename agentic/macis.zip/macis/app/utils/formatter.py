import json

def format_as_bullet_list(data, indent_level=0):
    """
    Recursively formats a Python dictionary or list into a bulleted list string.
    """
    formatted_string = ""
    indent = "    " * indent_level # 4 spaces per indent level
    
    if isinstance(data, dict):
        for key, value in data.items():
            formatted_string += f"{indent}* **{key}**:\n"
            formatted_string += format_as_bullet_list(value, indent_level + 1)
    elif isinstance(data, list):
        for item in data:
            # Check if the item is a complex type (dict or list) or a simple type
            if isinstance(item, (dict, list)):
                formatted_string += f"{indent}* \n"
                formatted_string += format_as_bullet_list(item, indent_level + 1)
            else:
                formatted_string += f"{indent}* {item}\n"
    else:
        # Handle simple data types (string, int, float, bool, None)
        formatted_string += f"{indent}  {data}\n"

    return formatted_string